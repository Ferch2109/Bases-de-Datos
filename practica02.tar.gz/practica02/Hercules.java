import hercules.src.clases.*;

public class Hercules{
	
	public static void main( String [] args ){

		
	}
	
}