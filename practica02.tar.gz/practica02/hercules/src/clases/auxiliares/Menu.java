package hercules.src.clases.auxiliares;

/**
 * Enumeración para manejar las opciones del menú.
 **/
public enum Menu{

	CREAR,
	ELIMINAR,
	ACTUALIZAR,
	BUSCAR;
}